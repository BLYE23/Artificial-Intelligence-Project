package bn.inference;

import bn.core.Assignment;

import java.util.Set;

import bn.base.BayesianNetwork;
import bn.base.BooleanDomain;
import bn.base.BooleanValue;
import bn.base.CPT;
import bn.base.NamedVariable;
import bn.core.Distribution;
import bn.core.RandomVariable;
import bn.core.Value;
import bn.util.ArrayMap;
import bn.util.ArraySet;

public class RejectionSamplingInferencer {

	//Constructor
	public RejectionSamplingInferencer() {
		super();
	}

	//a query method which returns the distribution of P(X|e). This method use a default number of samples.
	public Distribution query(RandomVariable X, Assignment e, BayesianNetwork network) {
		int n = 1000000;
		double count = 0.0;
		Distribution dist = new bn.base.Distribution(X);
		PriorSampler sample = new PriorSampler(network);
		ArrayMap<Value, Integer> N = new ArrayMap<Value, Integer>();
		for (Value i : X.getDomain()) {
			N.put(i, 0);
		}
		for (int i = 0; i < n; i++) {
			Assignment a = sample.getSample();
			if (isConsistent(a, e)) {
				count++;
				N.put(a.get(X), N.get(a.get(X)) + 1);
			}
		}
		for (Value i : X.getDomain()) {
			double d = N.get(i) / count;
			dist.set(i, d);
		}
		dist.normalize();
		return dist;
	}

	//a query method which returns the distribution of P(X|e). This method allow user to input specific
	//number of samples.
	public Distribution query(RandomVariable X, Assignment e, BayesianNetwork network, int n) {
		double count = 0.0;
		Distribution dist = new bn.base.Distribution(X);
		PriorSampler sample = new PriorSampler(network);
		ArrayMap<Value, Integer> N = new ArrayMap<Value, Integer>();
		for (Value i : X.getDomain()) {
			N.put(i, 0);
		}
		for (int i = 0; i < n; i++) {
			Assignment a = sample.getSample();
			if (isConsistent(a, e)) {
				count++;
				N.put(a.get(X), N.get(a.get(X)) + 1);
			}
		}
		for (Value i : X.getDomain()) {
			double d = N.get(i) / count;
			dist.set(i, d);
		}
		dist.normalize();
		return dist;
	}

	//a protected method which is used to decide whether two assignments is consistent,
	protected boolean isConsistent(Assignment x, Assignment e) {
		if (x.containsAll(e)) {
			return true;
		} else {
			return false;
		}
	}

}