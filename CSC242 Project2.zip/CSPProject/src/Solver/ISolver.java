package Solver;

public interface ISolver {

     boolean solve();

}
