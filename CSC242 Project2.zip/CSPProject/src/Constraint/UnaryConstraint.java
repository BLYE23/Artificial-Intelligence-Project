package Constraint;

import Variable.Variable;

public abstract class UnaryConstraint implements IConstraint{

    protected final Variable x;

    public UnaryConstraint(Variable x)
    {
        this.x = x;
    }
// check whether the constraint is related to variable
    @Override
    public boolean isRelateToVariable(Variable to)
    {
        return x == to;
    }

    
}
