package bn.inference;
// Inference by Enumeration algorithm for exact inference 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import bn.base.BooleanDomain;
import bn.base.BooleanValue;
import bn.base.CPT;
import bn.base.NamedVariable;
import bn.core.*;
import bn.util.ArrayMap;
import bn.util.ArraySet;

public class EnumerationInferencer implements bn.core.Inferencer {
	public EnumerationInferencer() {

	}

	@Override
	public Distribution query(RandomVariable X, Assignment e, BayesianNetwork network) {//function Enumeration-Ask(X,e,bn)
		bn.base.Distribution Q = new bn.base.Distribution(X);//initiate a distribution over X
		for (bn.core.Value v : X.getDomain()) {//for each value xi of X do
			e.put(X, v);//exi is e extended with X = xi
			Q.set(v, ENUMERATE_ALL(network.getVariablesSortedTopologically(), e, network));//Q(xi)<-Enumerate-All (bn.Vars, exi)
		}
		Q.normalize();//Normalize Q(x)
		return Q;//return a distribution over x
	}

	//return a distribution over x


	private double ENUMERATE_ALL(List<RandomVariable> vars, Assignment e, BayesianNetwork bn) {//function Enumerate-All(vars,e), return a real number(probability)
		if (vars.isEmpty()) {//if EMPTY?(vars)
			return 1.0;//then return 1.0
		}
		List<RandomVariable> temp = new ArrayList<RandomVariable>();//Y<-First(vars)

		for (RandomVariable var : vars) {
			temp.add(var);
		}

		RandomVariable Y = temp.remove(0);
		if (e.containsKey(Y)) {//if Y has value y in e
			double prob = bn.getProbability(Y, e) * ENUMERATE_ALL(temp, e, bn);
			return prob;//return P(y|parents(Y))xEnumerate-All(Rest(vars),e)
		} else {
			double prob = 0;
			for (bn.core.Value v : Y.getDomain()) {//Y does not have value y in e
				Assignment a = e.copy();
				a.put(Y, v);//a is e extended with Y=y
				prob += bn.getProbability(Y, a) * ENUMERATE_ALL(temp, a, bn);
			}
			return prob;//return sum of P(y|parents(Y)*Enumerate-All(Rest(vars),ey))
		}

	}
}