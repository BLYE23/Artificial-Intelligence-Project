package game;

import java.util.ArrayList;
import java.lang.*;

public class Board {
    char[][] gameboard;
    private final char[] indexes = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
    private int userColor;
    private int size;

    public Board(int color, int size) {
        gameboard = new char[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j <size; j++) {
                if((i==size/2-1)&&(j==size/2-1)){
                    this.gameboard[i][j]='W';
                }else if((i==size/2-1)&&(j==size/2)){
                    this.gameboard[i][j]='B';
                }else if((i==size/2)&&(j==size/2-1)){
                    this.gameboard[i][j]='B';
                }else if((i==size/2)&&(j==size/2)){
                    this.gameboard[i][j]='W';
                }else{
                    this.gameboard[i][j]='_';
                }

            }
        }
        this.userColor = color;
        this.size=size;
    }

    /**
     *
     * @return usercolor
     */
    public int getUserColor() {
        return userColor;
    }
    public int getSize() {
        return size;
    }

    public Board(Board b) {
        gameboard = new char[b.size][b.size];
        for (int i = 0; i < b.size; i++) {
            for (int j = 0; j < b.size; j++) {
                this.gameboard[i][j] = b.gameboard[i][j];
            }
        }
        this.userColor = b.userColor;
        this.size = b.getSize();
    }

    /**
     *
     * @param player
     * @return total pieces for the given player
     */
    public int CalculatePieces(int player,int size) {
        char ATMPlayer = player == 1 ? 'B' : 'W';
        int pieces = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (gameboard[i][j] == ATMPlayer)
                    pieces++;
            }
        }
        return pieces;
    }

    /**
     *
     * @return difference between player's and AI's pieces
     */
    public int CalculateAiPieceDifference() {
        int diff = CalculatePieces(1,size) - CalculatePieces(2,size);
        return userColor == 1 ? diff : -diff;
    }

    public void displayBoard(int size) {
        System.out.print("\n  ");
        for (int i = 0; i < size; ++i) System.out.print(indexes[i] + " ");
        System.out.println();
        for (int i = 0; i < size; ++i) {
            System.out.print((i + 1) + " ");
            for (int j = 0; j < size; ++j)
                System.out.print(gameboard[i][j] + " ");
            System.out.print((i+1) + " ");
            System.out.println();
        }
        System.out.print("  ");
        for (int i = 0; i < size; ++i) System.out.print(indexes[i] + " ");
        System.out.println();
    }
    /**
     *
     * @param gameboard
     * sets current gameboard as the one given
     */
    public void setGameboard(char[][] gameboard) {
        this.gameboard = gameboard;
    }


    /**
     * @param X
     * @param Y
     * @param player
     * @return True if the move is possible, false otherwise
     * also makes the move
     */

    public boolean makeMove(int X, int Y, int player, int size) {
        char playerPiece = player == 1 ? 'B' : 'W';
        char OpponentPiece = playerPiece == 'B' ? 'W' : 'B';
        boolean validMove = false;
        if (gameboard[X][Y] == '_') {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if (i == 0 && j == 0) {
                        continue;   //do not check the move position
                    }
                    boolean piecesToFlip = false, passedOpponent = false;
                    int k = 1;
                    while ((X + j * k >= 0 && X + j * k < size) && (Y + i * k >= 0 && Y + i * k < size)) {
                        if ((gameboard[X + j * k][Y + i * k] == '_') || (gameboard[X + j * k][Y + i * k] == playerPiece && !passedOpponent)) {
                            break;
                        }
                        if (gameboard[X + j * k][Y + i * k] == playerPiece && passedOpponent) {
                            piecesToFlip = true;
                            break;
                        } else if (gameboard[X + j * k][Y + i * k] == OpponentPiece) {
                            passedOpponent = true;
                            k++;
                        }
                    }
                    if (piecesToFlip) {

                        gameboard[X][Y] = playerPiece;

                        for (int h = 1; h <= k; h++) {
                            gameboard[X + j * h][Y + i * h] = playerPiece;
                        }

                        validMove = true;
                    }
                }
            }
        }
        return validMove;
    }

    /**
     * @param player
     * @return an  arraylist with boards
     * that contain all possible moves
     */
    public ArrayList<Board> findValidMoves(int player,int size) {
        ArrayList<Board> moves = new ArrayList<>();
        Board b = new Board(this);
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (b.makeMove(i, j, player,size)) {
                    moves.add(b);
                    b = new Board(this);
                }
            }
        }
        return moves;
    }

    /**
     *
     * boolean function
     * @return True if the game is over, false elsewhere
     */
    public boolean IsTerminal(){
        ArrayList <Board> moves1 = new ArrayList<>();
        ArrayList <Board> moves2 = new ArrayList<>();
        moves1 = findValidMoves(1,size);
        moves2 = findValidMoves(2,size);
        return moves1.isEmpty() && moves2.isEmpty();
    }

    /**
     * boolean function
     * @return True if the player can not move
     */
    
    public boolean haveValidMoves() {
    	ArrayList <Board> moves1 = new ArrayList<>();
        moves1 = findValidMoves(1,size);
        ArrayList <Board> moves2 = new ArrayList<>();
   	    moves2 = findValidMoves(2,size);
        return moves1.isEmpty() && moves2.isEmpty();
    }
    public boolean BhaveValidMoves(){
        ArrayList <Board> moves1 = new ArrayList<>();
        moves1 = findValidMoves(1,size);
        return !moves1.isEmpty();
    }
    
    public boolean WhaveValidMoves() {
    	 ArrayList <Board> moves2 = new ArrayList<>();
    	 moves2 = findValidMoves(2,size);
    	 return !moves2.isEmpty();
    }

    /**
     *
     * @param move
     * @param player
     * @return true if the string given by the user is a valid move
     * also makes the move
     */
    public boolean placeMove(String move, int player) {
        int Y = Integer.parseInt(String.valueOf(move.charAt(0) - 96)) - 1;
        int X = Integer.parseInt(String.valueOf(move.charAt(1))) - 1;
        return  makeMove(X, Y, player,size) ;
    }


    /**
     *
     * @return the current gameboard
     */
    public char[][] getGameboard() {
        return gameboard;
    }
    
    public double utility(Board b) {
		double utility;
		if(b.getUserColor() == 1) {
			if(b.CalculatePieces(1, b.getSize()) < b.CalculatePieces(2, b.getSize())) {
				utility = 64;
			}
			else if(b.CalculatePieces(1, b.getSize()) > b.CalculatePieces(2, b.getSize())) {
				utility = -64;
			}
			else{
				utility = 0;
			}
		}
		else{
			if(b.CalculatePieces(1, b.getSize()) > b.CalculatePieces(2, b.getSize())) {
				utility = 64;
			}
			else if(b.CalculatePieces(1, b.getSize()) < b.CalculatePieces(2, b.getSize())) {
				utility = -64;
			}
			else{
				utility = 0;
			}
		}
		return utility;
	}
    
    public double heuristic(Board b) {
    	char player;
    	char opponent;
    	if(b.getUserColor() == 1) {
    		player = 'B';
    		opponent = 'W';
    	}
    	else {
    		player = 'W';
    		opponent = 'B';
    	}
    	//corner
    	double score = 0;
    	
    	int playertilec = 0;
    	int oppotilec = 0;
    	int cornercheck = 0;
    	if(gameboard[0][0] == player) {
    		playertilec++;
    	}
    	else if(gameboard[0][0] == opponent) {
    		oppotilec++;
    	}
    	if(gameboard[0][b.size-1] == player) {
    		playertilec++;
    	}
    	else if(gameboard[0][b.size-1] == opponent) {
    		oppotilec++;
    	}
    	if(gameboard[b.size-1][b.size-1] == player) {
    		playertilec++;
    	}
    	else if(gameboard[b.size-1][b.size-1] == opponent) {
    		oppotilec++;
    	}
    	if(gameboard[b.size-1][0] == player) {
    		playertilec++;
    	}
    	else if(gameboard[b.size-1][0] == opponent) {
    		oppotilec++;
    	}
    	cornercheck = 25*(playertilec - oppotilec);
    	
    	//next to corner
    	int playertilenc=0;
        int oppotilenc=0;
        double ncornercheck =0;
        if(gameboard[0][0] == '_') {
            if (gameboard[0][1] == player){
                playertilenc++;
                }
            else if (gameboard[0][1] == opponent){
                oppotilenc++;
                }
            if (gameboard[1][1] == player){
                playertilenc++;
                }
            else if (gameboard[1][1] == opponent){
                oppotilenc++;
                }
            if (gameboard[1][0] == player){
                playertilenc++;
                }
            else if (gameboard[1][0] == opponent){
                oppotilenc++;
                }
        }
        if(gameboard[b.size-1][b.size-1] == '_') {
            if (gameboard[b.size-2][b.size-1] == player){
                playertilenc++;
                }
            else if (gameboard[b.size-2][b.size-1] == opponent){
                oppotilenc++;
                }
            if (gameboard[b.size-2][b.size-2] == player){
                playertilenc++;
                }
            else if (gameboard[b.size-2][b.size-2] == opponent){
                oppotilenc++;}
            if (gameboard[b.size-1][b.size-2] == player){
                playertilenc++;
                }
            else if (gameboard[b.size-1][b.size-2] == opponent){
                oppotilenc++;}
        }
        if(gameboard[0][b.size-1] == '_') {
            if (gameboard[0][b.size-2] == player){
                playertilenc++;}
            else if (gameboard[0][b.size-2] == opponent){
                oppotilenc++;}
            if (gameboard[1][b.size-2] == player){
                playertilenc++;}
            else if (gameboard[1][b.size-2] == opponent){
                oppotilenc++;}
            if (gameboard[1][b.size-1] == player){
                playertilenc++;}
            else if (gameboard[1][b.size-1] == opponent){
                oppotilenc++;}
        }
        if(gameboard[b.size-1][0] == '_') {
            if (gameboard[b.size-2][0] == player){
                playertilenc++;}
            else if (gameboard[b.size-2][0] == opponent){
                oppotilenc++;}
            if (gameboard[b.size-2][1] == player){
                playertilenc++;}
            else if (gameboard[b.size-2][1] == opponent){
                oppotilenc++;}
            if (gameboard[b.size-1][1] == player){
                playertilenc++;}
            else if (gameboard[b.size-1][1] == opponent){
                oppotilenc++;}
        }
        ncornercheck = -12.5*(playertilenc-oppotilenc);


        //Mobility


        score = (801.724 * cornercheck) + (382.026 * ncornercheck);

        return score;
    }
    

}
