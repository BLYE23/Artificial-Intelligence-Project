package Solver;

import Constraint.IConstraint;
import Problem.Problem;
import Variable.Variable;

import java.util.ArrayList;

public final class Solver implements ISolver {

    private final Problem problem;
    private final ArrayList<Variable> vars;
    private final ArrayList<IConstraint> cons;
    private int currentVariableIdx;
    private boolean trueForOneSolutionFalseForAllSolutions;

    public Solver(Problem problem) {
        this.problem = problem;
        vars = problem.getVars();
        cons = problem.getConstraints();
        trueForOneSolutionFalseForAllSolutions = true;
    }



    /*backtrack search method*/
    public boolean solve() {

        currentVariableIdx = 0;
        while (true) {
            
            if (!vars.get(currentVariableIdx).assign()) {//if assignment failure
                vars.get(currentVariableIdx).undoAssignment();
                currentVariableIdx--; //go back to last variable
                if (currentVariableIdx < 0 || (currentVariableIdx == 0 && !vars.get(0).canBeAssignment())) //this problem is unsolvable
                {
                    return false;
                }
                continue;
            }
            if (isAllConsistency()) {//if is consistency
                currentVariableIdx++; //go to next variable
                if (currentVariableIdx == vars.size()) //find a solution
                {
                    problem.addSolution();
                    if (!trueForOneSolutionFalseForAllSolutions) //go on search
                    {
                        currentVariableIdx--;
//                        vars.get(currentVariableIdx).goSearchAgain();
                    } else
                        break; // jump out

                }
            }
        }
        return true;
    }
//helper function check whether each progress is consistent
    private boolean isAllConsistency() {
        for (IConstraint c : cons)
            if (c.isRelateToVariable(vars.get(currentVariableIdx)) && !c.isConsistency())
                return false;
        return true;
    }

}
