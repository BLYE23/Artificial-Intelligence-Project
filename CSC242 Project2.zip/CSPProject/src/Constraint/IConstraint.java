package Constraint;

import Variable.Variable;

public interface IConstraint {

     boolean isConsistency();

     boolean isRelateToVariable(Variable to);
}
