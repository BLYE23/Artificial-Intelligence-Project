package game;

import java.util.*;
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Reversi, You will be playing vs an AI \n" +
                "Please choose the max depth of minimax and the colour of your choice, just remember black goes first :)");
        System.out.print("Enter the size of the board(An even number greater than or equal to 4): ");
        int size = Integer.parseInt(scanner.nextLine());
        //System.out.print("Enter the max depth of minimax: ");
        //int depth = Integer.parseInt(scanner.nextLine());
        System.out.print("Enter the colour of your choice: B for Black or W for white: ");

        Minimax AI = new Minimax();
        String choice = scanner.nextLine();
        int playerNo;//鐜╁鐨勪笅妫嬮『搴�
        int AIno;//AI鐨勪笅妫嬮『搴�
        int nowPlaying;//褰撳墠涓嬫鐨勪汉
        switch (choice) {
            case "B":
                System.out.println("You chose to go first, select one of the possible moves");
                playerNo = 1;
                AIno = 2;
                break;
            case "W" :
                System.out.println("Ai starting");
                playerNo = 2;
                AIno = 1;
                break;
            default: throw new IllegalStateException("Unexpected value: " + choice);
        }
        Board b = new Board(playerNo,size);
        nowPlaying = 1 ;
        b.displayBoard(size);
        int scorePlayer = 2;//鐜╁鍒嗘暟
        int scoreAI = 2;//AI鍒嗘暟
        while (!b.IsTerminal()){
            if (nowPlaying == playerNo) {
                if (!b.haveValidMoves()){
                    System.out.println("Your Round,please enter your move: (e.g. b2)");
                    choice = scanner.nextLine();
                    while (!b.placeMove(choice, playerNo)) {
                        System.out.println("Incorrect move please choose one of the valid moves shown");
                        choice = scanner.nextLine();
                    }
                }
            }
            else{
                System.out.println("AI's Round");
                AI.action(b);
            }
            b.displayBoard(size);
            scorePlayer = b.CalculatePieces(playerNo,size);
            scoreAI = b.CalculatePieces(AIno,size);
            System.out.println("Current score: " + scorePlayer + " "+ " "+scoreAI);
            if(nowPlaying == 1) {
            	if(b.WhaveValidMoves()) {
            		nowPlaying = nowPlaying % 2 + 1;
            	}
            }
            else {
            	if(b.BhaveValidMoves()) {
            		nowPlaying = nowPlaying % 2 + 1;
            	}
            }
        }

        if (scoreAI > scorePlayer ) {
            System.out.println("The winner is Ai with score: " + scorePlayer + " "+ " "+scoreAI);
        }
        else  if (scoreAI < scorePlayer ){
            System.out.println("The winner is You with score: " + scorePlayer + " "+ " "+scoreAI);
        }
        else{
            System.out.println("Tie with score: " + scorePlayer + " "+ " "+scoreAI);
        }
    }
}
