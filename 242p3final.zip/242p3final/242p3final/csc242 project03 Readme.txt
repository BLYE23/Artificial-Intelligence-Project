Course Name: CSC242
Project3
Name: Puhua Ye
Email:pye3@u.rochester.edu
Name of Collaborator: Puhua Ye
Email of Collaborator: pye3@u.rochester.edu

Part1: Instruction to run the project
1. change the directory to the src directory
2.using javac Main.java to create Main.class
3.using java Main with different argument to run the program:
   1)if you want to run the enumeration inferencer, you should use:
       java Main ExactInferencer filepath queryVariable Evidence(evidence variable and assigned value)    
      example:java Main ExactInferencer /bn/examples/aima-alarm.xml B J true M true (Because I put the file in the bn/examples folder so I do not include path)
    2)if you want to run the Likelihood inferencer, you should use:
       java Main LikelihoodInferencer filepath numberofsamples queryVariable Evidence(evidence variable and assigned value)    
      example:java Main LikelihoodInferencer 10000 /bn/examples/aima-alarm.xml B J true M true (Because I put the file in the bn/examples folder so I do not include path)
    3)if you want to run the Rejection Sampling inferencer, you should use:
       java Main RejectionInferencer filepath numberofsamples queryVariable Evidence(evidence variable and assigned value)    
      example:java Main RejectionInferencer 10000 /bn/examples/aima-alarm.xml B J true M true (Because I put the file in the bn/examples folder so I do not include path)

Part2: Project Explaination
We used the base, core, and parser package the professor gave. And we write our own Main.class
and inference package.
Inferencer folder:
EnumerationInferencer.java: This is an exact inferencer method. In the enumeration inferencer, there are 2
		              methods. One is query which returns the exact distribution of query variable 
                                              given evidence. Another method is Enumerate_All, which is used to calculate
		              specific probability.
Likelihood_Weighting.java:    This is the likelihood weighting inference.There are 4 methods. First function is 
		              Random_sample, which generates a random sample for the computation in the 
		              Weight_Sample function. The second is Weight_Sample function, each non evidence 
		              variable is sampled according to the assignemnt given on the values for the variable’s parents, 
		              while a weight is accumulated on the likelihood for each evidence. Then there are 2 query
		              methods, one of which allow user to specify the number of samples. Both of 2 methods
		              return the normalized distribution of query variable given evidence.
Prior_Sampling.java: The prior_sampling class is used to generate a random assignment for variable according to their
		  cpt in the network. The getSample() method is used to generate an assignment to all variables in
		  the network. randomSampleForVariable() method is used to assign a random value according to 
		  the assignment of its parents variable.
RejectionSamplingInfernecer.java: This is the Rejection sampling inferencer. There are 3 methods. The protected isConsistent()
			       method is used to decide whether 2 given assigment are same on their assigned value for same
			       variables. The other 2 methods both return the distribution of a given variable according to given
			       assignment. One of which allow user to specify the number of samples.