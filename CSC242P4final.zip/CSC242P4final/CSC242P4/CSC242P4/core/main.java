

import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import learn.lc.core.LogisticClassifier;
import learn.lc.core.PerceptronClassifier;
import learn.lc.core.LinearClassifier;
import learn.lc.core.DecayingLearningRateSchedule;
import learn.lc.core.Example;
import learn.lc.core.LearningRateSchedule;

public class main {
	public static List<Example> example(String fileName) throws IOException {
		List<Example> examples = new ArrayList<Example>();
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		String line;
		while ((line = in.readLine()) != null) {
			String[] line_split = line.split(",");
			double[] inputs = new double[line_split.length];
			inputs[0] = 1.0;
			for (int i = 1; i < line_split.length; i++) {
				inputs[i] = Double.parseDouble(line_split[i - 1]);
			}
			double output = Double.parseDouble(line_split[line_split.length - 1]);
			Example example = new Example(inputs, output);
			examples.add(example);
		}
		in.close();
		return examples;
	}

	public static void main(String[] args) throws IOException {
		String classifier_type = args[0];
		String fileName = args[1];
		int nsteps = Integer.parseInt(args[2]);
		double alpha = Double.parseDouble(args[3]);
		List<Example> examples = example(fileName);
		int ninputs = examples.get(0).inputs.length;
		LinearClassifier lc = null;
		if (classifier_type.equals("perceptron")) {
			lc = new PerceptronClassifier(ninputs);
		} else if (classifier_type.equals("logistic")) {
			lc = new LogisticClassifier(ninputs);
		}
		if (alpha > 0.0) {
			lc.train(examples, nsteps, alpha);
		} else {
			lc.train(examples, nsteps, new DecayingLearningRateSchedule());
		}
	}
}
