package Constraint;

import Variable.Variable;

public final class PrecedenceConstraint extends BinaryConstraint {

    private final int d;

    public PrecedenceConstraint(Variable x, Variable y, int d) {
        super(x, y);
        this.d = d;
    }

//check consistency that a work needs to be done first before the next for jobshop ('before') in the txt
    @Override
    public boolean isConsistency() {
        if(!x.isAssignment() || !y.isAssignment())
            return true;
        return x.getValue() + d <= y.getValue();
    }
}
