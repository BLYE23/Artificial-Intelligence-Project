package Constraint;

import Variable.Variable;

public abstract class BinaryConstraint implements IConstraint {

    protected final Variable x;
    protected final Variable y;
//structure for binary constraint
    public BinaryConstraint(Variable x, Variable y) {
        this.x = x;
        this.y = y;
    }
// if the constraint is realted to the variable
    @Override
    public boolean isRelateToVariable(Variable to)
    {
        return x == to || y == to;
    }
}
