package game;
import java.util.ArrayList;

public class Minimax {
	
	public void action(Board board) {
		ArrayList<Board> moves = board.findValidMoves(board.getUserColor()%2+1,board.getSize());
		Board action = new Board(moves.get(0));
		if(board.getUserColor() == 1) {
			double max;
			boolean Bhave = false;
			for (int i = 0; i < moves.size(); i++) {
				if(moves.get(i).BhaveValidMoves()|| moves.get(i).IsTerminal()) {
					Bhave = true;
					max = min_value(moves.get(i));
					if(max <= min_value(moves.get(i))) {
						max = min_value(moves.get(i));
						action = moves.get(i);
					}
				}
			}
			
			for(int i = 0; i < moves.size(); i++) {
				if(!Bhave & moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()){
					max = max_value(moves.get(i));
					if(max <= max_value(moves.get(i))) {
						max = max_value(moves.get(i));
						action = moves.get(i);
					}
				}
			}
		}
		
		if(board.getUserColor() == 2) {
			double max;
			boolean Whave = false;
			for (int i = 0; i < moves.size(); i++) {
				if(moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()) {
					Whave = true;
					max = min_value(moves.get(i));
					if(max <= min_value(moves.get(i))) {
						max = min_value(moves.get(i));
						action = moves.get(i);
					}
				}
			}
			
			for(int i = 0; i < moves.size(); i++) {
				if(!Whave & moves.get(i).BhaveValidMoves()|| moves.get(i).IsTerminal()){
					max = max_value(moves.get(i));
					if(max <= max_value(moves.get(i))) {
						max = max_value(moves.get(i));
						action = moves.get(i);
					}
				}
			}
		}
		board.setGameboard(action.getGameboard());
	}
		
	public double max_value(Board board) {
		if(board.IsTerminal()) {
			//System.out.println("The max_utility is" + utility(board));
			return board.utility(board);
		}
		ArrayList<Board> moves = board.findValidMoves(board.getUserColor()%2+1,board.getSize());
		double v = -10000000;
		double z;
		if(board.getUserColor() == 1) {
			boolean Bhave = false;
			for(int i = 0; i < moves.size();i++) {
				if(moves.get(i).BhaveValidMoves()|| moves.get(i).IsTerminal()) {
					Bhave = true;
					z = min_value(moves.get(i));
					if(z >= v) {
						v = z;
					}
				}
			}
			
			for(int i = 0; i < moves.size();i++) {
				if(!Bhave & moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()) {
					z = max_value(moves.get(i));
					if(z >= v) {
						v=z;
					}
				}
			}
		}
		
		if(board.getUserColor() == 2) {
			boolean Whave = false;
			for(int i = 0; i < moves.size();i++) {
				if(moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()) {
					Whave = true;
					z = min_value(moves.get(i));
					if(z >= v) {
						v = z;
					}
				}
			}
			
			for(int i = 0; i < moves.size();i++) {
				if(!Whave & moves.get(i).BhaveValidMoves()|| moves.get(i).IsTerminal()) {
					z = max_value(moves.get(i));
					if(z >= v) {
						v=z;
					}
				}
			}
		}
		//System.out.println("The max_value is" + v);
		return v;
	}
	
	public double min_value(Board board) {
		if(board.IsTerminal()) {
			//System.out.println("The min_utility is" + utility(board));
			return board.utility(board);
		}
		ArrayList<Board> moves = board.findValidMoves(board.getUserColor(),board.getSize());
		double v = 10000000;
		double z;
		if(board.getUserColor() == 1) {
			boolean Whave = false;
			for(int i = 0; i < moves.size();i++) {
				if(moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()) {
					Whave = true;
					z = max_value(moves.get(i));
					if(z <= v) {
						v = z;
					}
				}
			}
			
			for(int i = 0; i < moves.size();i++) {
				if(!Whave & moves.get(i).BhaveValidMoves()|| moves.get(i).IsTerminal()) {
					z = min_value(moves.get(i));
					if(z <= v) {
						v=z;
					}
				}
			}
		}
		
		if(board.getUserColor() == 2) {
			boolean Bhave = false;
			for(int i = 0; i < moves.size();i++) {
				if(moves.get(i).BhaveValidMoves() || moves.get(i).IsTerminal()) {
					Bhave = true;
					z = max_value(moves.get(i));
					if(z <= v) {
						v = z;
					}
				}
			}
			
			for(int i = 0; i < moves.size();i++) {
				if(!Bhave & moves.get(i).WhaveValidMoves()|| moves.get(i).IsTerminal()) {
					z = min_value(moves.get(i));
					if(z <= v) {
						v=z;
					}
				}
			}
		}
		//System.out.println("The min_value is" + v);
		return v;
	}
}

