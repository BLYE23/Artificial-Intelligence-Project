package Problem;

import Constraint.VariableDiffFromVariableConstraint;
import Constraint.VariableXMinusVariableYNotEqualXMinusYConstraint;
import Variable.Domain;
import Variable.Variable;
import Variable.Solution;

public final class NQueenProblem extends Problem {

    private final int N;

    //constructor
    public NQueenProblem(int N) {
        this.N = N;
        readInstance();
    }

    @Override
    public void readInstance() {
    //variables named Q1, Q2, ..., Qn each with domain {0,1,...,N-1} 
        for (int i = 0; i < N; i++) {
            Domain d = new Domain(0, N);
            Variable v = new Variable("Q" + i, d);
            addVar(v);
        }
        for (int i = 0; i < N; i++) {
            for (int j = i+1; j < N; j++) {
            	//add constraint which used to check whether two queens are in the same diagonal line
            	addConstraint(new VariableXMinusVariableYNotEqualXMinusYConstraint(vars.get(i), i, vars.get(j), j));
            	//add constraint which used to check whether two queens are in the same row
            	addConstraint(new VariableDiffFromVariableConstraint(vars.get(i), vars.get(j)));
            }
        }


    }

    @Override
    public void printSolution() {

        if (solutions.size() != 1)
            System.out.println("no solution");
        for (Variable v : vars) {
            for (int i = 0; i < v.getValue(); i++) {
                System.out.print("O ");
            }
            System.out.print("X ");
            for (int i = 0; i < N - v.getValue() - 1; i++) {
                System.out.print("O ");
            }
            System.out.println();
        }

    }
}
