package Constraint;

import Variable.Variable;

public final class CapacityConstraint extends BinaryConstraint {



    private final int di;
    private final int dj;

    public CapacityConstraint(Variable x, int di,Variable y, int dj) {
        super(x, y);
        this.di = di;
        this.dj = dj;
    }

// check consistency of capacity of the jobshop csp for the work ('disjoint in the txt')
    @Override
    public boolean isConsistency() {
        if(!x.isAssignment() || !y.isAssignment())
            return true;
        return x.getValue() + di <= y.getValue() || y.getValue() + dj <= x.getValue();
    }
}
